#ifndef _PLAN_H_
#define _PLAN_H_
#include "main.h"

extern volatile uint8_t Host_Car_Run_Flag;
extern volatile uint16_t Mark;
void plan(void);




#endif

