#ifndef _FENG_HUO_H_
#define _FENG_HUO_H_
#include "main.h"
#include "infrared.h"


void Feng_Huo_send(u8 *data);
void Fen_Huo_Rewrite(void);
void Feng_huo_Open(u8 *data);


#endif

