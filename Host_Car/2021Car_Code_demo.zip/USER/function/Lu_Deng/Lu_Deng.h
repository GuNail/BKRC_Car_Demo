#ifndef _LU_DENG_H_
#define _LU_DENG_H_
#include "main.h"
#include "infrared.h"

void Lu_Deng_Gears_1(void);
void Lu_Deng_Gears_2(void);
void Lu_Deng_Gears_3(void);
uint8_t Lu_Deng_set_light(uint8_t ger);
#endif
