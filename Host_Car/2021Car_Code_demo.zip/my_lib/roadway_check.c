#include "stm32f4xx.h"
#include "CanP_Hostcom.h"
#include "delay.h"
#include "roadway_check.h"
#include "cba.h"
#include "Timer.h"
#include "DEBUG.h"
#include "Fun_motor.h"
#include "rc522.h"

#include "data_base.h"
#include "A72.h"

#include <stdio.h>

volatile uint8_t Find_Line_Track_Flag=0;
volatile uint8_t Track_Go_Flag=0;
volatile uint8_t Track_Back_Flag=0;
volatile uint8_t Track_Back_Mp_Flag=0;
volatile uint8_t Track_Go_Mp_Flag=0;
volatile uint8_t Track_Card_Flag=0;
volatile uint8_t wheel_L_Flag =0;
volatile uint8_t wheel_R_Flag = 0;
volatile uint8_t wheel_Nav_Flag = 0;
volatile uint8_t Go_Flag = 0;
volatile uint8_t Back_Flag = 0;
volatile uint8_t Track_Flag = 0;
volatile uint8_t MP_Track_flag=0;
volatile uint8_t Stop_Flag = 0;
volatile int LSpeed = 0;
volatile int RSpeed = 0;
volatile int Car_Spend = 0;

volatile uint16_t temp_MP = 0;
volatile uint16_t temp_Nav = 0;

volatile uint8_t Line_Flag = 0;
volatile uint16_t count = 0;
volatile uint32_t Wheel_flag = 0;



void Track_Correct(uint8_t gd);
void Back_Track(uint8_t gd);

//_________________________________________________________
int16_t Roadway_cmp;
extern int16_t CanHost_Mp;

uint8_t CT[2];

/*
	����ͬ��
**/
void Roadway_mp_syn(void)
{
	Roadway_cmp = CanHost_Mp;
}

/*
	���̻�ȡ
**/
uint16_t Roadway_mp_Get(void)
{
	uint32_t ct;
	if(CanHost_Mp > Roadway_cmp)
		ct = CanHost_Mp - Roadway_cmp;
	else
		ct = Roadway_cmp - CanHost_Mp;
	if(ct > 0x8000)
		ct = 0xffff - ct;
	return ct;	
}
//________________________________________________________
uint16_t Roadway_Navig;
extern uint16_t CanHost_Navig;
/*
	�Ƕ�ͬ��
**/
void Roadway_nav_syn(void)
{
	Roadway_Navig = CanHost_Navig;
}

/*
	��ȡ�ǶȲ�ֵ
**/
uint16_t Roadway_nav_Get(void)
{
	uint16_t ct;
	if(CanHost_Navig > Roadway_Navig)
		ct = CanHost_Navig - Roadway_Navig;
	else
		ct = Roadway_Navig - CanHost_Navig;
	while(ct >= 36000)
		ct -= 36000;
	return ct;
}
//�����־λ
void Roadway_Flag_clean(void)
{
	Track_Back_Mp_Flag=0;
	Track_Go_Mp_Flag=0;
	MP_Track_flag=0;
	Stop_Flag = 0;
	Back_Flag = 0;
	Go_Flag = 0; 
	wheel_L_Flag = 0;
	wheel_R_Flag = 0;
	wheel_Nav_Flag = 0;
	Track_Flag = 0;
	Track_Back_Flag=0;
	Track_Go_Flag=0;
	Car_Spend = 0;
	temp_MP = 0;
}

uint8_t Roadway_GoBack_Check(void)
{
	return ((Go_Flag == 0)&&(Back_Flag == 0)&&(Track_Flag == 0)&&(wheel_L_Flag == 0)&&(wheel_R_Flag == 0))? 1:0;
}
/**
	ǰ�����
*/
void Go_and_Back_Check(void)
{	
	if(Go_Flag == 1)
	{
		if(temp_MP <= Roadway_mp_Get())
		{
			Go_Flag = 0;
			Stop_Flag = 0x03;
			Send_UpMotor(0,0);
			return;
		}
	} 
	else if(Back_Flag == 1)
	{
		if(temp_MP <= Roadway_mp_Get())
		{
			Back_Flag = 0;
			Stop_Flag=0x03;
			Send_UpMotor(0,0);
			return;
		}
	}
}

/**����ת��*/
void wheel_Nav_check(void)
{ 	
	uint16_t Mp_Value = 0;
	
	if(wheel_Nav_Flag)
	{
		Mp_Value = Roadway_mp_Get(); 
		if(Mp_Value >= temp_Nav)
		{
			wheel_Nav_Flag = 0;
			Stop_Flag = 0x02;
			Send_UpMotor(0,0);
			return;
		}
	}
}

/**����ѭ����ת��*/
uint32_t Mp_Value = 0;
void wheel_Track_check(void)
{ 	
	uint16_t Track_Value = 0;
	
	if(wheel_L_Flag == 1)
	{
		Track_Value = Get_Host_UpTrack(TRACK_H8);
		if(!(Track_Value &0X08)) //�ҵ�ѭ���ߣ�ֹͣ
		{	
			if(Wheel_flag > 50)
			{
				wheel_L_Flag = 0;
				Wheel_flag=0;
				Stop_Flag=0x02;
				Send_UpMotor(0,0);
				return;
			}
		}
		else if(Track_Value == 0Xff)
		{			
			Wheel_flag++;
		}
	} 
	else if(wheel_R_Flag == 1)
	{
		Track_Value = Get_Host_UpTrack(TRACK_H8);
		 if(!(Track_Value &0X10)) //�ҵ�ѭ���ߣ�ֹͣ
			{	
				if(Wheel_flag > 50)
				{
					wheel_R_Flag=0;
					Wheel_flag=0;
					Stop_Flag=0x02;
					Send_UpMotor(0,0);
					return;
				}
			}
			else if( Track_Value == 0Xff) 
			{				
				Wheel_flag++;
			}
	}
}

/***************************************************************
** ���ܣ�    �ٷ�ѭ�����������߲���һ�㲻ʹ��
** ������	 gd Ѱ����ֵ
** ����ֵ��   ��
****************************************************************/
void Track_Correct_official(uint8_t gd)
{
	if(Get_Host_UpTrack(TRACK_Q7) == 0x00)	//ѭ����ȫ�� ֹͣ
	{	
		Track_Flag = 0;
		Stop_Flag = 1;
		Track_Back_Flag=0;
		Track_Go_Flag=0;
		Send_UpMotor(0,0);
		return;
	}
	else
	{
	  Stop_Flag=0;
		if(gd==0XE7||gd==0XF7||gd==0XEF)//1���м�3/4��������⵽���ߣ�ȫ������
		{ 
			LSpeed=Car_Spend;
			RSpeed=Car_Spend;
		}
		if(Line_Flag!=2)
		{		

			if(gd==0XF3||gd==0XFB) //2���м�4��3��������⵽���ߣ�΢�ҹ�	
			{ 
				LSpeed=Car_Spend+30;
				RSpeed=Car_Spend-30;
				Line_Flag=0;
			}
			else if(gd==0XF9||gd==0XFD)//3���м�3��2��������⵽���ߣ���΢�ҹ�		
			{ 
				 LSpeed=Car_Spend+40;
				 RSpeed=Car_Spend-60;				 
				 Line_Flag=0;
			}
			else if(gd==0XFC)//4���м�2��1��������⵽���ߣ�ǿ�ҹ�
			{ 
				LSpeed = Car_Spend+50;
				RSpeed = Car_Spend-90;
				Line_Flag=0;
			}
			else if(gd==0XFE)//5�����ұ�1��������⵽���ߣ���ǿ�ҹ�			
			{ 
				 LSpeed = Car_Spend+60;
				 RSpeed = Car_Spend-120;			
				 Line_Flag=1;
			}
		}
		if(Line_Flag!=1)
		{
			if(gd==0XCF)//6���м�6��5��������⵽���ߣ�΢���			
			{ 
				 RSpeed = Car_Spend+30;
				 LSpeed = Car_Spend-30;
				 Line_Flag=0;
			} 
			else if(gd==0X9F||gd==0XDF)//7���м�7��6��������⵽���ߣ���΢���		 
			{ 
				 RSpeed = Car_Spend+40;
				 LSpeed = Car_Spend-60;
				 Line_Flag=0;
			} 			  
			else if(gd==0X3F||gd==0XBF)//8���м�8��7��������⵽���ߣ�ǿ���		 
			{ 
				 RSpeed = Car_Spend+50;
				 LSpeed = Car_Spend-90;
				 Line_Flag=0;
			} 
			else if(gd==0X7F)//9������8��������⵽���ߣ���ǿ���		 	
			{ 
				 RSpeed = Car_Spend+60;
				 LSpeed = Car_Spend-120;
				 Line_Flag=2;
			}			
		}
		if(Get_Host_UpTrack(TRACK_ALL)==0xFF7F)   //ѭ����ȫ��
		{
			if(count > Track_MaxError)
			{
				count=0;
				Send_UpMotor(0,0);
				Track_Flag=0;
				Track_Back_Flag=0;
				Track_Go_Flag=0;
				if(Line_Flag ==0) 
				Stop_Flag=0x02;
				return;
			}	
			else 
				count++;				
		}
		else 
			count=0;
	}
	if(Track_Flag != 0)
	{
			Control(LSpeed,RSpeed);
	}
}

/*Ѱ�����ơ���ǰ��**/
void Track_Control_Go(uint8_t gd)
{
	uint16_t All_gd=Get_Host_UpTrack(TRACK_ALL);
	if(Get_Host_UpTrack(TRACK_Q7) == 0x00)	//ѭ����ȫ�� ֹͣ
	{	
		Track_Flag = 0;
		Track_Go_Flag=0;
		Stop_Flag = 0x01;
		Send_UpMotor(0,0);
		return;
	}
	else
	{
	  if(gd==0XE7) 
		{ 		
			LSpeed=Car_Spend;
			RSpeed=Car_Spend;	
		}
		else	if(gd==0XF7)		
		{
			LSpeed=Car_Spend+30;
			RSpeed=Car_Spend-40;	
		}
		else	if(gd==0XEF)
		{
			LSpeed=Car_Spend-40;
			RSpeed=Car_Spend+30;	
		}	
		else	if(gd==0XF3||gd==0XFB)
		{ 
			LSpeed=Car_Spend+30;
			RSpeed=Car_Spend-40;	
		}
		else if(gd==0XF9||gd==0XFD)
		{ 
			 LSpeed=Car_Spend+60;
			 RSpeed=Car_Spend-70;				 
		}
		else if(gd==0XFC)
		{ 
			LSpeed = Car_Spend+60;
			RSpeed = Car_Spend-90;	
		}
		else if(gd==0XFE)		
		{ 
			 LSpeed = Car_Spend+80;
			 RSpeed = Car_Spend-120;					
		}
		else if(gd==0XCF)
		{ 
			 RSpeed = Car_Spend+30;
			 LSpeed = Car_Spend-40;	
		} 
		else if(gd==0X9F||gd==0XDF) 
		{ 
			 RSpeed = Car_Spend+60;
			 LSpeed = Car_Spend-70; 
		} 			  
		else if(gd==0X3F||gd==0XBF)
		{ 
			 RSpeed = Car_Spend+70;
			 LSpeed = Car_Spend-90;	 
		} 
		else if(gd==0X7F) 	
		{ 
			 RSpeed = Car_Spend+80;
			 LSpeed = Car_Spend-120;	 
		}	
		else if(All_gd==0xFF7F)
		{
			if(count >= Track_MaxError)
			{
				count=0;
				Track_Go_Flag=0;
				Send_UpMotor(0,0);
				Track_Flag=0;
				Stop_Flag=0x04;
				return;
			}	
			else 
			{
				count++;			
			}		
		}
		else 
		{
			count=0;
		}	
	}
	if(Track_Flag != 0)
	{
		Control(LSpeed,RSpeed);
	}
}
/***Ѱ�����ơ�������**/
void Track_Control_Back(uint8_t gd)
{
	uint16_t All_gd=Get_Host_UpTrack(TRACK_ALL);
	if(Get_Host_UpTrack(TRACK_Q7) == 0x00)	//ѭ����ȫ�� ֹͣ
	{	
		Track_Flag = 0;
		Track_Back_Flag=0;
		Stop_Flag = 0x01;
		Send_UpMotor(0,0);
		return;
	}
	else
	{
	  if(gd==0XE7) 
		{ 		
			LSpeed=Car_Spend;
			RSpeed=Car_Spend;	
		}
		else	if(gd==0XF7)		
		{
			LSpeed=Car_Spend+30;
			RSpeed=Car_Spend-40;	
		}
		else	if(gd==0XEF)
		{
			LSpeed=Car_Spend-40;
			RSpeed=Car_Spend+30;	
		}	
		else	if(gd==0XF3||gd==0XFB)
		{ 
			LSpeed=Car_Spend+30;
			RSpeed=Car_Spend-40;	
		}
		else if(gd==0XF9||gd==0XFD)
		{ 
			 LSpeed=Car_Spend+60;
			 RSpeed=Car_Spend-70;				 
		}
		else if(gd==0XFC)
		{ 
			LSpeed = Car_Spend+60;
			RSpeed = Car_Spend-90;	
		}
		else if(gd==0XFE)		
		{ 
			 LSpeed = Car_Spend+80;
			 RSpeed = Car_Spend-120;					
		}
		else	if(gd==0XCF)
		{ 
			 RSpeed = Car_Spend+30;
			 LSpeed = Car_Spend-40;	
		} 
		else if(gd==0X9F||gd==0XDF) 
		{ 
			 RSpeed = Car_Spend+60;
			 LSpeed = Car_Spend-70; 
		} 			  
		else if(gd==0X3F||gd==0XBF)
		{ 
			 RSpeed = Car_Spend+70;
			 LSpeed = Car_Spend-90;	 
		} 
		else if(gd==0X7F) 	
		{ 
			 RSpeed = Car_Spend+80;
			 LSpeed = Car_Spend-120;	 
		}	
		else if(All_gd==0xFF7F)
		{
			if(count >= Track_MaxError)
			{
				count=0;
				Track_Back_Flag=0;
				Send_UpMotor(0,0);
				Track_Flag=0;
				Stop_Flag=0x04;
				return;
			}	
			else 
			{
				count++;			
			}		
		}
		else 
		{
			count=0;
		}	
	}
	if(Track_Flag != 0)
	{
		Control(LSpeed,RSpeed);
	}
}

/**ǰ��ָ������Ѱ��**/
void Track_Control_Go_Mp(uint8_t gd)
{
	if(Get_Host_UpTrack(TRACK_Q7) == 0x00)	//ѭ����ȫ�� ֹͣ
	{	
		MP_Track_flag = 0;
		Stop_Flag = 0x01;
		Track_Go_Mp_Flag=0;
		Send_UpMotor(0,0);
		return;
	}
	else
	{
	  if(gd==0XE7)   
		{ 		
			LSpeed=Car_Spend;
			RSpeed=Car_Spend;	
		}
		else	if(gd==0XF7)		
		{
			LSpeed=Car_Spend+30;
			RSpeed=Car_Spend-40;	
		}
		else	if(gd==0XEF)
		{
			LSpeed=Car_Spend-40;
			RSpeed=Car_Spend+30;	
		}	
		else	if(gd==0XF3||gd==0XFB) 	
		{ 
			LSpeed=Car_Spend+30;
			RSpeed=Car_Spend-40;	
		}
		else if(gd==0XF9||gd==0XFD)	
		{ 
			 LSpeed=Car_Spend+60;
			 RSpeed=Car_Spend-70;				 
		}
		else if(gd==0XFC)
		{ 
			LSpeed = Car_Spend+60;
			RSpeed = Car_Spend-90;	
		}
		else if(gd==0XFE)		
		{ 
			 LSpeed = Car_Spend+80;
			 RSpeed = Car_Spend-120;					
		}
		else	if(gd==0XCF)	
		{ 
			 RSpeed = Car_Spend+30;
			 LSpeed = Car_Spend-40;	
		} 
		else if(gd==0X9F||gd==0XDF)		 
		{ 
			 RSpeed = Car_Spend+60;
			 LSpeed = Car_Spend-70; 
		} 			  
		else if(gd==0X3F||gd==0XBF)		 
		{ 
			 RSpeed = Car_Spend+70;
			 LSpeed = Car_Spend-90;	 
		} 
		else if(gd==0X7F) 	
		{ 
			 RSpeed = Car_Spend+80;
			 LSpeed = Car_Spend-120;	 
		}		
		else if(gd==0xFF)   //ѭ����ȫ��
		{
			if(count > 2000)
			{
				count=0;
				MP_Track_flag=0;
				Stop_Flag=0x04;
				Track_Go_Mp_Flag=0;
				Send_UpMotor(0,0);
				return;
			}	
			else 
				count++;				
		}
		else 
			count=0;
	}
	if(temp_MP <= Roadway_mp_Get())
	{
		Stop_Flag = 0x03;
		Track_Go_Mp_Flag=0;
		MP_Track_flag = 0;
		Send_UpMotor(0,0);
		return;
	}
	if(MP_Track_flag!=0)
	{
		Control(LSpeed,RSpeed);
	}
}

/***����ָ������Ѱ��****/
void Track_Control_Back_Mp(uint8_t gd)
{
	if(gd == 0x00)	//ѭ����ȫ�� ֹͣ
	{	
		Stop_Flag = 0x01;
		Track_Back_Mp_Flag=0;
		MP_Track_flag = 0;
		Send_UpMotor(0,0);
		return;
	}
	else
	{
	  if(gd==0XE7)   
		{ 		
			LSpeed=Car_Spend;
			RSpeed=Car_Spend;	
		}
		else	if(gd==0XF7)		
		{
			LSpeed=Car_Spend+30;
			RSpeed=Car_Spend-40;
		}
		else	if(gd==0XEF)
		{
			LSpeed=Car_Spend-40;
			RSpeed=Car_Spend-30;
		}	
		else	if(gd==0XF3||gd==0XFB) 	
		{ 
			LSpeed=Car_Spend+30;
			RSpeed=Car_Spend-40;	
		}
		else if(gd==0XF9||gd==0XFD)	
		{ 
			 LSpeed=Car_Spend+60;
			 RSpeed=Car_Spend-70;				 
		}
		else if(gd==0XFC)
		{ 
			LSpeed = Car_Spend+60;
			RSpeed = Car_Spend-90;	
		}
		else if(gd==0XFE)		
		{ 
			 LSpeed = Car_Spend+80;
			 RSpeed = Car_Spend-120;					
		}
		else	if(gd==0XCF)	
		{ 
			 LSpeed = Car_Spend+30;
			 RSpeed = Car_Spend-40;	
		} 
		else if(gd==0X9F||gd==0XDF)		 
		{ 
			 LSpeed = Car_Spend+60;
			 RSpeed = Car_Spend-70; 
		} 			  
		else if(gd==0X3F||gd==0XBF)		 
		{ 
			 LSpeed = Car_Spend+70;
			 RSpeed = Car_Spend-90;	 
		} 
		else if(gd==0X7F) 	
		{ 
			 LSpeed = Car_Spend+80;
			 RSpeed = Car_Spend-120;	 
		}		
		else if(gd==0xFF)   //ѭ����ȫ��
		{
			if(count > Track_MaxError)
			{
				count=0;
				Track_Flag=0;
				Track_Back_Mp_Flag=0;
				Stop_Flag=0x04;
				Send_UpMotor(0,0);
				return;
			}	
			else 
				count++;				
		}
		else 
			count=0;
	}
	if(temp_MP <= Roadway_mp_Get())
	{
		Stop_Flag = 0x03;
		Track_Go_Mp_Flag=0;
		Track_Back_Mp_Flag=0;
		MP_Track_flag = 0;
		Send_UpMotor(0,0);
		return;
	} 
	if(MP_Track_flag!=0)
	{
			Control(LSpeed,RSpeed);
	}
}

void Find_Line_Track(uint8_t gd)
{
	  if(gd==0XE7) 
		{ 		
			Find_Line_Track_Flag=0;
			Send_UpMotor(0, 0);
			return;
		}
		else	if(gd==0XF7)		
		{
			Find_Line_Track_Flag=0;
			Send_UpMotor(0, 0);
			return;
		}
		else	if(gd==0XEF)
		{
			Find_Line_Track_Flag=0;
			Send_UpMotor(0, 0);
			return;
		}	
		else	if(gd==0XF3||gd==0XFB)
		{ 
			Find_Line_Track_Flag=0;
			Send_UpMotor(0, 0);
			return;
		}
		else if(gd==0XF9||gd==0XFD)
		{ 
			Find_Line_Track_Flag=0;
			Send_UpMotor(0, 0);
			return;
		}
		else if(gd==0XCF)
		{ 
			Find_Line_Track_Flag=0;
			Send_UpMotor(0, 0);
			return;
		} 
		else if(gd==0X9F||gd==0XDF) 
		{ 
			Find_Line_Track_Flag=0;
			Send_UpMotor(0, 0);
			return;
		} 			  

	if(Find_Line_Track_Flag != 0)
	{
		Control(Car_Spend,Car_Spend);
	}
}



void Card_Track(uint8_t gd)
{
	if(gd==0XE7)   
	{ 		
		LSpeed=Car_Spend;
		RSpeed=Car_Spend;	
	}
	else	if(gd==0XF7)		
	{
		LSpeed=Car_Spend+30;
		RSpeed=Car_Spend-40;	
	}
	else	if(gd==0XEF)
	{
		LSpeed=Car_Spend-40;
		RSpeed=Car_Spend+30;	
	}	
	else	if(gd==0XF3||gd==0XFB) 	
	{ 
		LSpeed=Car_Spend+30;
		RSpeed=Car_Spend-40;	
	}
	else if(gd==0XF9||gd==0XFD)	
	{ 
		 LSpeed=Car_Spend+60;
		 RSpeed=Car_Spend-70;				 
	}
	else if(gd==0XFC)
	{ 
		LSpeed = Car_Spend+60;
		RSpeed = Car_Spend-90;	
	}
	else if(gd==0XFE)		
	{ 
		 LSpeed = Car_Spend+80;
		 RSpeed = Car_Spend-120;					
	}
	else	if(gd==0XCF)	
	{ 
		 RSpeed = Car_Spend+30;
		 LSpeed = Car_Spend-40;	
	} 
	else if(gd==0X9F||gd==0XDF)		 
	{ 
		 RSpeed = Car_Spend+60;
		 LSpeed = Car_Spend-70; 
	} 			  
	else if(gd==0X3F||gd==0XBF)		 
	{ 
		 RSpeed = Car_Spend+70;
		 LSpeed = Car_Spend-90;	 
	} 
	else if(gd==0X7F) 	
	{ 
		 RSpeed = Car_Spend+80;
		 LSpeed = Car_Spend-120;	 
	}		
	if(temp_MP <= Roadway_mp_Get())
	{
		Stop_Flag = 0x03;
		Track_Go_Mp_Flag=0;
		MP_Track_flag = 0;
		Send_UpMotor(0,0);
		return;
	}
	if(MP_Track_flag!=0)
	{
		Control(LSpeed,RSpeed);
	}
}

void Stop_Flag_Cheack()
{
	delay_ms(1);
	if(Stop_Flag==0x04)
	{
		RFID_Cheack();
	}
}

uint8_t cheku=1;
void RFID_Cheack()
{
	uint16_t Track_Value[2];
	uint8_t res=0;
	delay_ms(5);
	Fun_Go_Back(60,80);
	delay_ms(5);
	Track_Value[1] = Get_Host_UpTrack(TRACK_ALL);
	uint16_t cont=BitCount(Track_Value[1]);
	uint16_t MP_1=Roadway_mp_Get();
	Find_Line();
	delay_ms(1);
	uint16_t MP_2=Roadway_mp_Get();
	if(MP_2-MP_1>=1000)
	{
		Fun_Track(60);
		delay_ms(10);
		Fun_Go_Back(60,380);
		delay_ms(10);
		return;
	}
	else
	{
		Fun_Go_Back(60,80);
		delay_ms(5);
		res=Read_Card(0x42,RFID_Card);
		delay_ms(5);
		if(cont<=2)
		{
			if(res==1)
			{
				if(Mark==36)
				{
					cheku=2;
				}
				else if(Mark==37)
				{
					cheku=3;
				}
			}
			Fun_Track(60);
			delay_ms(5);
			Fun_Go_Back(60,410);
			delay_ms(5);
		}
		else
		{
			if(Mark==36)
			{
					cheku=3;
			}
		}
	}
		res=0;
}



//void RFID_Cheack(uint8_t *Flag)
//{
//	int8_t status=0;
//	uint16_t Track_Value[2];
//	delay_ms(5);
//	Track_Value[1] = Get_Host_UpTrack(TRACK_ALL);
//	uint16_t cont=BitCount(Track_Value[1]);
//	Fun_Go_Back(60,70);
//	delay_ms(5);
//	Track_Value[0] = Get_Host_UpTrack(TRACK_Q7);
//	delay_ms(5);
//	if((Track_Value[0]&0x1C)==0x1C)
//	{
//		Fun_Go_Back(60,300);
//		Read_Card(0x01,RFID_Card);
//		delay_ms(5);
//		if(cont<=2)
//		{
//			Fun_Track(60);
//			delay_ms(5);
//			Fun_Go_Back(60,410);
//			return;
//		}
//		else
//		{
//			return;
//		}
//	}
//	else
//	{
//		Find_Line();
//		delay_ms(5);
//		Fun_Track(60);
//		delay_ms(5);
//		Fun_Go_Back(60,410);
//		return;
//	}
//}

/**ѭ�����*/
void Track_Check(void)
{	
	if(Track_Flag == 1)
	{
		if(Track_Go_Flag==1)
		{
#if official 
			Track_Correct_official(Get_Host_UpTrack(TRACK_H8));
#else
			Track_Control_Go(Get_Host_UpTrack(TRACK_H8));
#endif
		}
		else if(Track_Back_Flag==1)
		{
#if official
			Track_Correct_official(reverse_bit(Get_Host_UpTrack(TRACK_H8)));
#else
			Track_Control_Back(reverse_bit(Get_Host_UpTrack(TRACK_H8)));
#endif
		}
	}
	else if(MP_Track_flag==1)
	{
		if(Track_Go_Mp_Flag==1)
		{
			Track_Control_Go_Mp(Get_Host_UpTrack(TRACK_H8));
		}
		else if(Track_Back_Mp_Flag==1)
		{
			Track_Control_Back_Mp(reverse_bit(Get_Host_UpTrack(TRACK_H8)));
		}
	}
	else if(Find_Line_Track_Flag==1)
	{
		Find_Line_Track(Get_Host_UpTrack(TRACK_H8));
	}
	else if(Track_Card_Flag==1)
	{
		Card_Track(~(Get_Host_UpTrack(TRACK_H8)));
	}
	
}

void Roadway_Check(void)
{
	Go_and_Back_Check();
	wheel_Track_check();
	wheel_Nav_check();
	Track_Check();
}
	
/***************************************************************
** ���ܣ�     ������ƺ���
** ������	  L_Spend����������ٶ�
**            R_Spend����������ٶ�
** ����ֵ��   ��	  
****************************************************************/
void Control(int L_Spend,int R_Spend)
{
	if(L_Spend>=0)
	{	
		if(L_Spend>100)L_Spend=100;if(L_Spend<5)L_Spend=5;		//�����ٶȲ���
	}
	else 
	{
		if(L_Spend<-100)L_Spend= -100;if(L_Spend>-5)L_Spend= -5;     //�����ٶȲ���
	}	
	if(R_Spend>=0)
	{	
		if(R_Spend>100)R_Spend=100;if(R_Spend<5)R_Spend=5;		//�����ٶȲ���
	}
	else
	{	
		if(R_Spend<-100)R_Spend= -100;if(R_Spend>-5)R_Spend= -5;		//�����ٶȲ���		
	}
	Send_UpMotor(L_Spend ,R_Spend);	
}


void roadway_check_TimInit(uint16_t arr,uint16_t psc)
{
	TIM_TimeBaseInitTypeDef TIM_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM9,ENABLE);
	
	TIM_InitStructure.TIM_Period = arr;
	TIM_InitStructure.TIM_Prescaler = psc;
	TIM_InitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_InitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_InitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM9,&TIM_InitStructure);

	NVIC_InitStructure.NVIC_IRQChannel = TIM1_BRK_TIM9_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 5;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	TIM_ITConfig(TIM9,TIM_IT_Update,ENABLE);
	TIM_Cmd(TIM9, ENABLE);
}

void TIM1_BRK_TIM9_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM9,TIM_IT_Update) == SET)
	{
		Roadway_Check();				//·�����
	}
	TIM_ClearITPendingBit(TIM9,TIM_IT_Update);
}



//end file


