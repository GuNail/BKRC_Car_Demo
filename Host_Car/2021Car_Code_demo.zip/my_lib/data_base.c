#include "stm32f4xx.h"
#include "data_base.h"




uint8_t Principal_Tab[Principal_Length]; 
uint8_t Follower_Tab[Follower_Length];



